<!DOCTYPE html>
<html lang="ar" dir=" ">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">

  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.1.0/css/all.css" integrity="sha384-lKuwvrZot6UHsBSfcMvOkWwlCMgc0TaWr+30HWe3a4ltaBwTZhyTEggF5tJv8tbt"
      crossorigin="anonymous">
  <link rel="stylesheet" href="css1/stylehs.css">
  <link href="css1/c3p.css" rel="stylesheet">
  <link rel="stylesheet" href="css1/t1.css">
  <title>Lovers of Perfumes</title>



</head>
<body>
  <div id="slideout-menu">
        <ul>
            <li>
                <a href="Home.php">الرئسية</a>
            </li>
            <li>
                <a href="Perfume_concentration.php">تركيز العطر</a>
            </li>
            <li>
                <a href="Types_of_Scent_Families.php">انواع العطور</a>
            </li>
            <li>
                <a href="Share_your_experience.php">شارك تجربتك</a>
            </li>

        </ul>
    </div>

    <nav>
        <div id="logo-img">
            <a href="Home.php">
              <img src="https://i.ibb.co/SxZxQHx/1606493021985.png" alt="1606493021985" border="0">

            </a>
        </div>
        <div id="menu-icon">
            <i class="fas fa-bars"></i>
        </div>
        <ul>
            <li>
                <a class="active" href="Home.php">الرئسية</a>
            </li>
            <li>
                <a href="Perfume_concentration.php">تركيز العطر</a>
            </li>
            <li>
                <a href="Types_of_Scent_Families.php">انواع العطور</a>
            </li>
            <li>
                <a href="Share_your_experience.php">شارك تجربتك</a>
            </li>
            <li>
                <div id="search-icon">
                    <i></i>
                </div>
            </li>
        </ul>
    </nav>



    <div id="parallax-world-of-ugg">
  <section>
      <div class="parallax-one">
        <h2>العطور المنعشة</h2>
        <h2>(Fresh)</h2>

      </div>
  </section>

  <section>
    <div class="block"><br>
      <p><span class="first-character sc" dir="rtl">|</span><p>تشمل عائلة الرائحة المنعشة روائح نقية ومشرقة.  الروائح العشبية والحمضيات والمحيطات تندرج تحت هذه الفئة.  غالبًا ما تُستخدم في عطور الرجال أكثر من عطور النساء ، ويتم إقران الروائح المنعشة مع روائح حارة لخلق عطر أكثر قوة.  يمكن أيضًا العثور على الروائح العطرية اللاذعة ممزوجة برائحة منعشة أو فاكهية.</p>
</div>
  </section>

  <section>
    <div class="parallax-two">
      <h2>الانواع الفرعية</h2>
    </div>
  </section>

  <section>
    <div class="block">
      <span class="first-character ny">|</span>
      <h4>:( Aromatic)العطرية</h4>
    <p>.تمتاز رائحتها بالحيوية والانتعاش وغالبا ما تستخدم في العطور الرجالية، وتضم: اللافندر والخزامى وإكليل الجبل وعبارة عن هي  أعشاب نظيفة ومنعشة ممزوجة بالخزامى (اللافندر )أو عطور خشبية</p>
    <h4>: ( Citrus)الحمضيات</h4>
    <p>.توصف بأنها خفيفة ومنعشة وترفع المعنويات هي روائح منعشة  مثل الليمون و اليوسفي أو البرغموت</p>
    <h4>: (Water)العطور المائية </h4>
    <p>.الروائح المائية التي تفوح برائحة رذاذ البحر أو المطر ممزوجًا برائحة المحيط.
فتعكس شعورا بالانتعاش والبرودة، ولذلك هي مناسبة لفصل الصيف.</p>
<h4>:(Green)الخضراء</h4>
<p>.عطور مستخرجة من الاعشاب العطرية
زي الروزماري ، النعناع ، اكليل الجبل ، الريحان ، المُر ، الخزامى ، الباتشولي ... الخ</p>

    </div>
  </section>

  <section>
    <div class="parallax-three">
      <h2>روائح العطور المنعشة الشائعة</h2>
    </div>
  </section>

  <section>
    <div class="block">
<ul>
<li>(Sage)  المريمية نبات </li>
<li>(Bergamot  )  البرغموت</li>
<li>الخزامى</li>
<li>الليمون</li>
<li>الريحان</li>
</ul>
    </div>
  </section>

  <section>
    <div class="parallax-four">
    <h2>:أمثلة على العطور</h2>
    </div>
  </section>
  <section>
    <div class="block">
    <h3>:مواقع عربية مشهوره وموثوقه</h3>
    </div>
    <div class="blockimg " >
      <a href="https://www.noon.com/saudi-ar/"><img src="https://i.ibb.co/WfVgY5m/Pics-Art-11-20-10-15-33.png" alt="Pics-Art-11-14-01-40-20" ></a>

    <a href="https://ar-sa.namshi.com/?utm_source=google&utm_medium=cpc&utm_content=%D9%86%D9%85%D8%B4%D9%8A&utm_campaign=sa_search_cb-010001_namshi_ar_desktop-tab&gclid=CjwKCAiA7939BRBMEiwA-hX5J5ceWIwssbu9sdyX002uxa6hy97XG3DP6MNHuCliIIsmuWjt5iTJ8hoC0H0QAvD_BwE"><img src="https://i.ibb.co/dLvTNJf/Pics-Art-11-20-10-18-17.png" alt="Pics-Art-11-14-01-44-42" ></a>

      <a href="https://niceonesa.com/ar/"><img src="https://i.ibb.co/6bS7ZF1/Pics-Art-11-20-10-19-26.png" alt="Pics-Art-11-14-01-35-20" ></a>

      <a href="https://bharqan.com/"><img src="https://i.ibb.co/TgxL7pW/Pics-Art-11-20-10-20-23.png" alt="Pics-Art-11-14-01-51-03"  ></a>


    </div>
  </section>

  </div>

  <div class="accordian">
  <ul>
  <li>
  <div class="image_title">
    <a href="https://en-sa.namshi.com/buy-davidoff-cool-water-man-125ml-edt-440292.html">Cool Water – Davidoff</a>
  </div>
  <a href="https://en-sa.namshi.com/buy-davidoff-cool-water-man-125ml-edt-440292.html">
  <img src="https://i.ibb.co/KNGb9mN/IMG-2896-x-1629-pixel.jpg" alt="IMG-2896-x-1629-pixel" border="0">
  </a>
  </li>
  <li>
  <div class="image_title">
    <a href="https://www.noon.com/saudi-en/eau-fraiche-edt-200ml/N11201395A/p">Versace Man – Versace</a>
  </div>
  <a href="https://www.noon.com/saudi-en/eau-fraiche-edt-200ml/N11201395A/p">
<img src="https://i.ibb.co/P10mxZt/IMG-2896-x-1629-pixel.jpg" alt="IMG-2896-x-1629-pixel" border="0">
  </a>
  </li>
  <li>
  <div class="image_title">
    <a href="https://www.sephora.sa/ar/p/%22%D8%A3%D9%83%D9%88%D8%A7-%D8%AF%D9%8A-%D8%AC%D9%8A%D9%88-%D9%BE%D9%88%D8%B1-%D8%A3%D9%88%D9%85%22-%D9%85%D8%A7%D8%A1-%D8%AA%D9%88%D8%A7%D9%84%D9%8A%D8%AA-P2277.html">Acqua di Gio – Giorgio Armani</a>
  </div>

  <a href="https://www.sephora.sa/ar/p/%22%D8%A3%D9%83%D9%88%D8%A7-%D8%AF%D9%8A-%D8%AC%D9%8A%D9%88-%D9%BE%D9%88%D8%B1-%D8%A3%D9%88%D9%85%22-%D9%85%D8%A7%D8%A1-%D8%AA%D9%88%D8%A7%D9%84%D9%8A%D8%AA-P2277.html">
  <img src="https://i.ibb.co/HY2hzfT/IMG-2896-x-1629-pixel.jpg" alt="IMG-2896-x-1629-pixel" border="0">
  </a>

  </li>
  <li>
  <div class="image_title">
    <a href="https://bharqan.com/products/c38d8c15-3201-426e-b443-7ec5e73ff98d">عطر المطر - Rain</a>
  </div>
  <a href="https://bharqan.com/products/c38d8c15-3201-426e-b443-7ec5e73ff98d">
<img src="https://i.ibb.co/VjmmPjb/IMG-2896-x-1629-pixel.jpg" alt="IMG-2896-x-1629-pixel" border="0">
  </a>
  </li>
  <li>
  <div class="image_title">
    <a href="https://store.asqgrp.com/sa_ar/black-incense.html">بلاك إنسنس</a>
  </div>

  <a href="https://store.asqgrp.com/sa_ar/black-incense.html">
  <img src="https://i.ibb.co/PW4GL4w/IMG-2896-x-1629-pixel.jpg" alt="IMG-2896-x-1629-pixel" border="0">
  </a>
  </li>
  </ul>
  </div>







  <footer>
          <div id="left-footer">
              <h3>روابط سريعة</h3>

                  <ul>
                      <li>
                          <a href="Home.php">الرئسية</a>
                      </li>
                      <li>
                          <a href="personality_test.php">اختبار الشخصية</a>
                      </li>
                      <li>
                          <a href="Perfume_concentration.php">تركيز العطر</a>
                      </li>
                      <li>
                          <a href="Types_of_Scent_Families.php">انواع العطور</a>
                      </li>
                      <li>
                          <a href="Share_your_experience.php">شارك تجربتك</a>
                      </li>

                  </ul>

          </div>

          <div id="right-footer">
              <h3>اتبعنا</h3>
              <div id="social-media-footer">
                  <ul>
                      <li>
                          <a href="#">
                              <i class="fab fa-facebook"></i>
                          </a>
                      </li>
                      <li>
                          <a href="#">
                              <i class="fab fa-youtube"></i>
                          </a>
                      </li>
                      <li>
                          <a href="#">
                              <i class="fab fa-github"></i>
                          </a>
                      </li>
                  </ul>
              </div>
              <p>This website is developed by IT Team</p>
          </div>
      </footer>

            <script src="js/j.js"></script>
            <script src="js1/min.js"></script>
            <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
            <!-- Include all compiled plugins (below), or include individual files as needed -->
            <script src="js1/bootstrap.min.js"></script>

    </body>
    </html>
