<?php
include_once 'database.php';
$result = mysqli_query($conn,"SELECT * FROM  Perfume_Info ORDER BY Id ASC");

?>
<!DOCTYPE html>
<html lang="ar" dir=" ">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">

  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.1.0/css/all.css" integrity="sha384-lKuwvrZot6UHsBSfcMvOkWwlCMgc0TaWr+30HWe3a4ltaBwTZhyTEggF5tJv8tbt"
      crossorigin="anonymous">
  <link rel="stylesheet" href="css1/stylehs.css">
  ]
  <link href="css1/c3p.css" rel="stylesheet">
    <title>Perfume Club</title>
    <style>
    body{position: relative; bottom: 85px;}
    footer {position: relative;top: 290px;}
    .creat h2{position: relative; top: 100px; color:#221C37; font-size: 100px; text-align: center;}
    </style>

</head>
<body>
  <div id="slideout-menu">
        <ul>
            <li>
                <a href="Home.php">الرئسية</a>
            </li>
            <li>
                <a href="Perfume_concentration.php">تركيز العطر</a>
            </li>
            <li>
                <a href="Types_of_Scent_Families.php">انواع العطور</a>
            </li>
            <li>
                <a href="Share_your_experience.php">شارك تجربتك</a>
            </li>

        </ul>
    </div>

    <nav>
        <div id="logo-img">
            <a href="Home.php">
              <img src="https://i.ibb.co/SxZxQHx/1606493021985.png" alt="1606493021985">

            </a>
        </div>
        <div id="menu-icon">
            <i class="fas fa-bars"></i>
        </div>
        <ul>
            <li>
                <a class="active" href="Home.php">الرئسية</a>
            </li>
            <li>
                <a href="Perfume_concentration.php">تركيز العطر</a>
            </li>
            <li>
                <a href="Types_of_Scent_Families.php">انواع العطور</a>
            </li>
            <li>
                <a href="Share_your_experience.php">شارك تجربتك</a>
            </li>
            <li>
                <div id="search-icon">
                    <i></i>
                </div>
            </li>
        </ul>
    </nav>


<main>
    <section class="creat">

<?php
$host="sql302.eb2a.com";
$user="eb2a_27334387";
$pass="Bb12345678";
$db="eb2a_27334387_perfume";
$conn=mysqli_connect($host,$user,$pass,$db);
if(!$conn){
   die('Could not Connect My Sql:' .mysql_error());
}
if(isset($_POST['Submit']))
{
	 $Title = $_POST['Title'];
	 $Post = $_POST['Post'];

	 $sql = "INSERT INTO Perfume_Info (Title,Post)
	 VALUES ('$Title','$Post')";
	 if (mysqli_query($conn, $sql)) {
    echo "<h2 >!تم الانشاء بنجاح</h2>";

	 } else {
		echo "Error: " . $sql . "
" . mysqli_error($conn);
	 }
	 mysqli_close($conn);
}
?>
</section>

<footer>
        <div id="left-footer">
            <h3>روابط سريعة</h3>

                <ul>
                    <li>
                        <a href="Home.php">الرئسية</a>
                    </li>
                    <li>
                        <a href="personality_test.php">اختبار الشخصية</a>
                    </li>
                    <li>
                        <a href="Perfume_concentration.php">تركيز العطر</a>
                    </li>
                    <li>
                        <a href="Types_of_Scent_Families.php">انواع العطور</a>
                    </li>
                    <li>
                        <a href="Share_your_experience.php">شارك تجربتك</a>
                    </li>

                </ul>

        </div>

        <div id="right-footer">
            <h3>اتبعنا</h3>
            <div id="social-media-footer">
                <ul>
                    <li>
                        <a href="#">
                            <i class="fab fa-facebook"></i>
                        </a>
                    </li>
                    <li>
                        <a href="#">
                            <i class="fab fa-youtube"></i>
                        </a>
                    </li>
                    <li>
                        <a href="#">
                            <i class="fab fa-github"></i>
                        </a>
                    </li>
                </ul>
            </div>
            <p>This website is developed by IT Team</p>
        </div>
    </footer>
    </main>
    <script src="js1/min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js1/bootstrap.min.js"></script>
</body>
</html>
