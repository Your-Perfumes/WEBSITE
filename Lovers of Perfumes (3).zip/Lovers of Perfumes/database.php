<?php
$host="sql302.eb2a.com";
$user="eb2a_27334387";
$pass="Bb12345678";
$db="eb2a_27334387_perfume";
$conn=mysqli_connect($host,$user,$pass,$db);
if(!$conn){
   die('Could not Connect My Sql:' .mysql_error());
}

?>
