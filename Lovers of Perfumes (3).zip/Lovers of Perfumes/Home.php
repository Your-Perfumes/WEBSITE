<!-- جميع الحقوق محفوظة
مصادر بعض الاكواد  المشروع
https://youtu.be/SbrlHqJqL6o
https://www.codeseek.co/heatherduvall/vuejs-personality-quiz-ggedwy
https://codepen.io/?s=08-->


<?php
include_once 'database.php';
$result = mysqli_query($conn,"SELECT * FROM  Perfume_Info ORDER BY Id ASC");

?>
<!DOCTYPE html>
<html lang="ar" dir=" ">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">

  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.1.0/css/all.css" integrity="sha384-lKuwvrZot6UHsBSfcMvOkWwlCMgc0TaWr+30HWe3a4ltaBwTZhyTEggF5tJv8tbt"
      crossorigin="anonymous">
  <link rel="stylesheet" href="css1/stylehs.css">
  <link href="css1/c3p.css" rel="stylesheet">
  <title>Lovers of Perfumes</title>
  <style >

  .typeim{position: relative; top: 200px;}
  footer {position: relative;top: 350px;}
  </style>


</head>
<body>
  <div id="slideout-menu">
        <ul>
            <li>
                <a href="Home.php">الرئسية</a>
            </li>
            <li>
                <a href="Perfume_concentration.php">تركيز العطر</a>
            </li>
            <li>
                <a href="Types_of_Scent_Families.php">انواع العطور</a>
            </li>
            <li>
                <a href="Share_your_experience.php">شارك تجربتك</a>
            </li>

        </ul>
    </div>

    <nav>
        <div id="logo-img">
            <a href="Home.php">
              <img src="https://i.ibb.co/SxZxQHx/1606493021985.png" alt="1606493021985">

            </a>
        </div>
        <div id="menu-icon">
            <i class="fas fa-bars"></i>
        </div>
        <ul>
            <li>
                <a class="active" href="Home.php">الرئسية</a>
            </li>
            <li>
                <a href="Perfume_concentration.php">تركيز العطر</a>
            </li>
            <li>
                <a href="Types_of_Scent_Families.php">انواع العطور</a>
            </li>
            <li>
                <a href="Share_your_experience.php">شارك تجربتك</a>
            </li>
            <li>
                <div id="search-icon">
                    <i></i>
                </div>
            </li>
        </ul>
    </nav>








    <div id="banner">
        <h1>&lt;!هل تريد معرفة الخط العطري الذي يناسب شخصيتك/&gt;</h1>
        <br><br>
        <a  href="personality_test.php"  class="btn2  btn-primary btn-lg role="button">!اضغط هنا</a>
    </div>

    <!-- Inicio Menu -->

        <!-- Fim Menu -->


		<div class="espaco-topo">
			<div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
			<!-- Indicators -->
				<ol class="carousel-indicators">
					<?php
						$controle_ativo = 2;
						$controle_num_slide = 1;
						$result_carousel = "SELECT * FROM  Perfume_Info ORDER BY Id ASC";
						$resultado_carousel = mysqli_query($conn, $result_carousel);
						while($row_carousel = mysqli_fetch_assoc($resultado_carousel)){
							if($controle_ativo == 2){ ?>
								<li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li><?php
								$controle_ativo = 1;
							}else{ ?>
								<li data-target="#carousel-example-generic" data-slide-to="<?php echo $controle_num_slide; ?>"></li><?php
								$controle_num_slide++;
							}
						}
					?>
				</ol>

				<!-- Wrapper for slides -->
				<div class="carousel-inner" role="listbox">
					<?php
						$controle_ativo = 2;
						$result_carousel = "SELECT * FROM Perfume_Info ORDER BY Id ASC";
						$resultado_carousel = mysqli_query($conn, $result_carousel);
						while($row_carousel = mysqli_fetch_array($resultado_carousel)){
							if($controle_ativo == 2){ ?>
								<div class="item active">
									<a href="https://ibb.co/PwtQSnp"><img src="https://i.ibb.co/pJnym8D/Pics-Art-11-13-03-14-47.jpg" alt="Pics-Art-11-13-03-14-47" border="0"></a>
									<h2 class="item2"><a href=""><?php echo $row_carousel["Title"]; ?></a></h2>
                  <p><?php echo $row_carousel["Post"]; ?></p>

								</div><?php
								$controle_ativo = 1;
							}else{ ?>
								<div class="item">
										<a href="https://ibb.co/PwtQSnp"><img src="https://i.ibb.co/pJnym8D/Pics-Art-11-13-03-14-47.jpg" alt="Pics-Art-11-13-03-14-47" border="0"></a>
									<h2><a href=""><?php echo $row_carousel["Title"]; ?></a></h2>
                  <p><?php echo $row_carousel["Post"]; ?></p>

								</div> <?php
							}
						}
					?>
				</div>

				<!-- Controls -->
				<a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">
					<span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
					<span class="sr-only">Previous</span>
				</a>
				<a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">
					<span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
					<span class="sr-only">Next</span>
				</a>
			</div>
		</div>



<main>
  <section>
        <div class="container">
            <div class="card">
                <div class="face face1">
                    <div class="content">
                        <h3>Perfume</h3>

                    </div>
                </div>
                <div class="face face0">
                    <div class="content">
                      <p>هي أغلى انواع العطور نظرًا حيث يصل تركيز الخلاصة بها إلي 40%, مدة بقاء هذه الأنواع من العطور : 8 إلى 6 ساعات. تباع في أحجام صغيرة نظراً لإرتفاع أسعاره. تعتبر هذه الفئة من العطور مناسبة للأشخاص ذوى البشرة الحساسة نظرًا لقلة نسبة الكحول، ويفضل استخدامها في فصل الشتاء بسبب قوتها.</p>


                    </div>
                </div>
            </div>
            <div class="card2">
                <div class="face face2">
                    <div class="content">
                    <h3>Eau de Parfum</h3>
                    </div>
                </div>
                <div class="face face0">
                    <div class="content">
                        <p>يتروح تركيز خلاصة العطر(الزيت) فيها بين 15% إلى 20%، ولذلك فهي أقل سعرًا من الفئة السابقة , مدة بقاء هذه الأنواع من العطور : 5 إلى 4 ساعات, كما أنه يعتبر مناسب لأصحاب البشرة الحساسة مقارنة بأنواع العطور الأخرى,.
    تعتبر هذه الفئة من العطور مناسبة للاستخدام أكثر في فصلي الخريف، والشتاء.
    </p>
                    </div>
                </div>
            </div>
            <div class="card3">
                <div class="face face3">
                    <div class="content">

                        <h3>Eau de Toilette</h3>
                    </div>
                </div>
                <div class="face face0">
                    <div class="content">
                    <p>أما هذا النوع يصل تركيز خلاصة العطور (الزيت) فيها بين 15٪ الى4% من العطر و هو ذو رائحة أخف من او دي برفيوم و أكثر إنتعاشاً، و مناسب أكثر للمناخ الأكثر دفئاً , مدة بقاء هذه الأنواع من العطور : 3 إلى 2 ساعات . ويعتبر من العطور المناسبة للاستخدام اليومي في فصلي الربيع، والصيف.</p>
                    </div>
                </div>
            </div>
            <div class="card4">
                <div class="face face4">
                    <div class="content">

                        <h3>Eau de Cologne</h3>
                    </div>
                </div>
                <div class="face face0">
                    <div class="content">
                        <p>يحتوي عطر او دي كولونيا على تركيز خلاصة العطور (الزيت) يصل فيها بين 5٪ الى2%، إنه منعش للمناخات الأكثر حرارة و هو من أنواع العطور التي تتبخر سريعاً لذلك فإنها تباع بكميات كبيرة و بسعر أقل من جميع انواع العطور الأخرى و أيضاً تعرف تركيز العطور فيها بأنها الأقل. مدة بقاء هذه الأنواع من العطور :  2 ساعة.</p>

                    </div>
                </div>
            </div>
            <div class="card5">
                <div class="face face5">
                    <div class="content">

                        <h3>Eau Fraiche</h3>
                    </div>
                </div>
                <div class="face face0">
                    <div class="content">
                        <p>تندرج تحت هذه الفئة العطور الأخف تركيزًا على الإطلاق، حيث تدوم لأقل ساعتين، بسبب أن نسبة تركيز الزيت العطري فيها قليلة جدًا، وتتراوح بين 1% إلى 3% فقط.</p>

                    </div>
                </div>
            </div>
        </div>
      </section>

      <section class="typeim">


        <a href="Floral.php"><img src="https://i.ibb.co/XsSTwCK/Pics-Art-11-14-01-40-20.png" alt="Pics-Art-11-14-01-40-20" ></a>

      <a href="Oriental.php"><img src="https://i.ibb.co/Pt7jgRH/Pics-Art-11-14-01-44-42.png" alt="Pics-Art-11-14-01-44-42" ></a>

        <a href="Woods.php"><img src="https://i.ibb.co/QHsvV6G/Pics-Art-11-14-01-35-20.png" alt="Pics-Art-11-14-01-35-20" ></a>

        <a href="Fresh.php"><img src="https://i.ibb.co/4SL7F8P/Pics-Art-11-14-01-51-03.png" alt="Pics-Art-11-14-01-51-03"  ></a>




       </section>

        <section>

          <div class="displayx">

            <h2 class="display-4">شارك تجربتك </h2>
            <h4 class="mt-4">.كن جزءًا من مجتمع  محبي العطور  , وشارك تجاربك عن العطور ، ابدأ الآن بإضافة تجربتك</h4>

            <a  href="Write_your_experience.php"  class="btn2  btn-primary btn-lg role=" button">شارك تجربتك</a>
            <div class="img-fluid">
            <img src="https://i.ibb.co/511kq0d/ecc6e29be0133c9323aa6c5c7bbaded0.jpg" alt="ecc6e29be0133c9323aa6c5c7bbaded0" border="0" width="300" height"300">
          </div>
          <div class="img-fluid2">
          <img src="https://i.ibb.co/HzzwxfV/5e718be2e16e28348706232df85c8c42.jpg" alt="5e718be2e16e28348706232df85c8c42" border="0" width="300" height"300">
        </div>
        </div>

        </section>
















    <footer>
            <div id="left-footer">
                <h3>روابط سريعة</h3>

                    <ul>
                        <li>
                            <a href="Home.php">الرئسية</a>
                        </li>
                        <li>
                            <a href="personality_test.php">اختبار الشخصية</a>
                        </li>
                        <li>
                            <a href="Perfume_concentration.php">تركيز العطر</a>
                        </li>
                        <li>
                            <a href="Types_of_Scent_Families.php">انواع العطور</a>
                        </li>
                        <li>
                            <a href="Share_your_experience.php">شارك تجربتك</a>
                        </li>

                    </ul>

            </div>

            <div id="right-footer">
                <h3>اتبعنا</h3>
                <div id="social-media-footer">
                    <ul>
                        <li>
                            <a href="#">
                                <i class="fab fa-facebook"></i>
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <i class="fab fa-youtube"></i>
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <i class="fab fa-github"></i>
                            </a>
                        </li>
                    </ul>
                </div>
                <p>This website is developed by IT Team</p>
            </div>
        </footer>
        </main>
        <script src="js1/min.js"></script>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
        <script src="js1/bootstrap.min.js"></script>
</body>
</html>
