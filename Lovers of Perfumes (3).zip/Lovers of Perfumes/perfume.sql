-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 28, 2020 at 04:16 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `perfume`
--

-- --------------------------------------------------------

--
-- Table structure for table `perfume_info`
--

CREATE TABLE `perfume_info` (
  `Id` int(11) NOT NULL,
  `Title` varchar(50) NOT NULL,
  `Post` mediumtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `perfume_info`
--

INSERT INTO `perfume_info` (`Id`, `Title`, `Post`) VALUES
(1, 'مرحبا بكم !', 'اكتب لنا هنا عن تجربتك في مختلف العطور|'),
(2, 'Midnight on Max Street (Emotional Oud) Philly&Phil', 'عود بطابع واسلوب شرقي عربي\r\nيختلف عن عطور العود التي جربتها من قبل سواء عود وود او عود فور جريتنيس او او،\r\nالعود هنا أكثر قتامة غامق جعل من العطر اكثر فخامة .. غاتم ولكنه ليس ثقيل او مزعج، رائحة محببة للنفس\r\nعود شرقي فاكهي سويت متوازِن تابلي فخم .. سيناسب عشاق العود العربي\r\n\r\nالعود يتصدر الافتتاحية بوضوح وبعد ان يهدا العطر سيتراجع قليلاً ويسير بجانب البرقوق ولكنه واضح\r\nالعود والبرقوق هما الاكثر وضوحاً ، والقرفة والفانيليا مكملين داعمين فاعلين للعطر وواضحين ،\r\nمن الاشياء الجميلة في العطر هو أن الورد خفيف جداً يكاد لا يذكر .. لمن لا يحبون الورد في عطور العود\r\n\r\nبأختصار ما ميز هذا العطر هو العود الداكن القاتم والبرقوق البرقوق البرقوق بديع وجميل\r\nالثبات فوق المتوسط .. مناسب للجنسين يميل قليلاً للرجال لسبب قتامته .. عطر يستحق التجربة'),
(3, 'Coach for Men Coach', 'هذا العطر من العطور الصيفيه الجميله\r\n\r\nالافضل ما تستعجل بالحكم عليه من مقدمة العطر لان هذا العطر نفسه طويل حتى ما يبان معك ويتحول من مرحلة المقدمة لمرحلة وسط العطر حتى يصل نهاية العطر والقاعده العطريه ، كل نص ساعه تمر عليه يدخل مكون عطري دخول متدرج حتى يوصل العطر لقمته\r\n\r\nالعطر مناسب للعمل والاجتماعات والطلعات لتمشيه في اماكن عامه\r\n\r\nالعطر بمقدمه حمضيه بسبب البرغموت والجريب فروت بعد فتره معتدله من الوقت تبدا تظهر لك المكونات في وسط العطر بالتدريج والقاعده العطريه .\r\n\r\nثباته جيد جدا إلى ممتاز\r\n\r\nأنتشاره وفوحانه متوسط ورائع\r\n\r\nللمعلومية : العطر أو دو تواليت.');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `perfume_info`
--
ALTER TABLE `perfume_info`
  ADD PRIMARY KEY (`Id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `perfume_info`
--
ALTER TABLE `perfume_info`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
