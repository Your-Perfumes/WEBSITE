<!DOCTYPE html>
<html lang="ar" dir=" ">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">

  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.1.0/css/all.css" integrity="sha384-lKuwvrZot6UHsBSfcMvOkWwlCMgc0TaWr+30HWe3a4ltaBwTZhyTEggF5tJv8tbt"
      crossorigin="anonymous">

  <link rel="stylesheet" href="css1/stylehs.css">
  <link href="css1/c3p.css" rel="stylesheet">
  <link rel="stylesheet" href="css1/t1.css">
  <title>Lovers of Perfumes</title>



</head>
<body>
  <div id="slideout-menu">
        <ul>
            <li>
                <a href="Home.php">الرئسية</a>
            </li>
            <li>
                <a href="Perfume_concentration.php">تركيز العطر</a>
            </li>
            <li>
                <a href="Types_of_Scent_Families.php">انواع العطور</a>
            </li>
            <li>
                <a href="Share_your_experience.php">شارك تجربتك</a>
            </li>

        </ul>
    </div>

    <nav>
        <div id="logo-img">
            <a href="Home.php">
              <img src="https://i.ibb.co/SxZxQHx/1606493021985.png" alt="1606493021985" border="0">

            </a>
        </div>
        <div id="menu-icon">
            <i class="fas fa-bars"></i>
        </div>
        <ul>
            <li>
                <a class="active" href="Home.php">الرئسية</a>
            </li>
            <li>
                <a href="Perfume_concentration.php">تركيز العطر</a>
            </li>
            <li>
                <a href="Types_of_Scent_Families.php">انواع العطور</a>
            </li>
            <li>
                <a href="Share_your_experience.php">شارك تجربتك</a>
            </li>
            <li>
                <div id="search-icon">
                    <i></i>
                </div>
            </li>
        </ul>
    </nav>



    <div id="parallax-world-of-ugg">
  <section>
      <div class="parallax-one">

        <h2>العطور الازهار</h2>
        <h2>(Floral)</h2>

      </div>
  </section>

  <section>
    <div class="block"><br>
      <p><span class="first-character sc" dir="rtl">|</span><p>عائلة رائحة الأزهار هي واحدة من أكثر العائلات شيوعًا وتستخدم في العديد من العطور المعروفة.  غالبًا ما تُستخدم روائح الأزهار في عطور النساء ، على الرغم من استخدامها أحيانًا في عطور الرجال أيضًا.  عادة ما تكون رائحتها مثل الزهور المقطوفة أو بالإحساس البودري الناعم الذي يتناسب مع السيدات</p>
</div>
  </section>

  <section>
    <div class="parallax-two">
      <h2>الانواع الفرعية</h2>
    </div>
  </section>

  <section>
    <div class="block">
      <span class="first-character ny">|</span>
      <h4>:(Fruity) فواكه</h4>
    <p>حلوة ، صالحة للأكل واستوائية مثل الخوخ والكمثرى والتفاح.(طبعا هي ليست صالحة للأكل ولكن هذي مواصفات رائحة )</p>
    <h4>:(Floral)الأزهار  رقية</h4>
    <p>رائحة مثل الزهور الطازجة - تخيل الورد والزنبق</p>
    <h4>:( Soft floral)الأزهار الناعمة</h4>
    <p>ناعمة ، بودرة وحلوة مع لمسة كريمية</p>
    <h4>:(  Floral oriental)الأزهار الشرقية </h4>
    <p> أزهار مع روائح التوابل الرقيقة</p>

    </div>
  </section>

  <section>
    <div class="parallax-three">
      <h2>روائح العطور الازهار الشائعة</h2>
    </div>
  </section>

  <section>
    <div class="block">
<ul>
<li>الورد(Rose)</li>
<li>ياسمين(Jasmine)</li>
<li>زهرة البرتقال(Orange blossom)</li>

</ul>
    </div>
  </section>

  <section>
    <div class="parallax-four">
    <h2>:أمثلة على العطور</h2>
    </div>
  </section>
  <section>
    <div class="block">
    <h3>:مواقع عربية مشهوره وموثوقه</h3>
    </div>
    <div class="blockimg " >
      <a href="https://www.noon.com/saudi-ar/"><img src="https://i.ibb.co/WfVgY5m/Pics-Art-11-20-10-15-33.png" alt="Pics-Art-11-14-01-40-20" ></a>

      <a href="https://ar-sa.namshi.com/?utm_source=google&utm_medium=cpc&utm_content=%D9%86%D9%85%D8%B4%D9%8A&utm_campaign=sa_search_cb-010001_namshi_ar_desktop-tab&gclid=CjwKCAiA7939BRBMEiwA-hX5J5ceWIwssbu9sdyX002uxa6hy97XG3DP6MNHuCliIIsmuWjt5iTJ8hoC0H0QAvD_BwE"><img src="https://i.ibb.co/dLvTNJf/Pics-Art-11-20-10-18-17.png" alt="Pics-Art-11-14-01-44-42" ></a>

      <a href="https://niceonesa.com/ar/"><img src="https://i.ibb.co/6bS7ZF1/Pics-Art-11-20-10-19-26.png" alt="Pics-Art-11-14-01-35-20" ></a>

      <a href="https://bharqan.com/"><img src="https://i.ibb.co/TgxL7pW/Pics-Art-11-20-10-20-23.png" alt="Pics-Art-11-14-01-51-03"  ></a>


    </div>
  </section>

  </div>

  <div class="accordian">
  <ul>
  <li>
  <div class="image_title">
    <a href="https://niceonesa.com/ar/perfume/women-perfumes/%D8%B9%D8%B7%D8%B1-%D8%A8%D9%84%D9%88%D9%85-%D9%85%D9%86-%D9%82%D9%88%D8%AA%D8%B4%D9%8A-%D9%84%D9%84%D9%86%D8%B3%D8%A7%D8%A1-%D8%A7%D9%88-%D8%AF%D9%8A-%D8%A8%D8%A7%D8%B1%D9%81%D9%8A%D9%88%D9%85-n7240/">(Bloom – Gucci)بلوم - غوتشي</a>
  </div>
  <a href="https://niceonesa.com/ar/perfume/women-perfumes/%D8%B9%D8%B7%D8%B1-%D8%A8%D9%84%D9%88%D9%85-%D9%85%D9%86-%D9%82%D9%88%D8%AA%D8%B4%D9%8A-%D9%84%D9%84%D9%86%D8%B3%D8%A7%D8%A1-%D8%A7%D9%88-%D8%AF%D9%8A-%D8%A8%D8%A7%D8%B1%D9%81%D9%8A%D9%88%D9%85-n7240/">
  <img src="https://i.ibb.co/SBjH5nT/IMG-2896-x-1629-pixel.jpg" alt="IMG-2896-x-1629-pixel" border="0">
  </a>
  </li>
  <li>
  <div class="image_title">
    <a href="https://en-sa.namshi.com/buy-elizabeth-arden-classic-red-door-50ml-edt-398087.html"> ( Red Door – Elizabeth Arden) رد دور - إليزابيث أردن</a>
  </div>
  <a href="https://en-sa.namshi.com/buy-elizabeth-arden-classic-red-door-50ml-edt-398087.html">
<img src="https://i.ibb.co/pRDpJSw/IMG-2896-x-1629-pixel.jpg" alt="IMG-2896-x-1629-pixel" border="0">
  </a>
  </li>
  <li>
  <div class="image_title">
    <a href="https://www.noon.com/saudi-ar/100/N15568070A/p">روكين ريو - اسكادا (Rockin’ Rio – Escada)</a>
  </div>

  <a href="https://www.noon.com/saudi-ar/100/N15568070A/p">
<img src="https://i.ibb.co/kmJFQf8/IMG-2896-x-1629-pixel.jpg" alt="IMG-2896-x-1629-pixel" border="0">
  </a>

  </li>
  <li>
  <div class="image_title">
    <a href="https://niceonesa.com/ar/Perfume/%D8%B9%D8%B7%D8%B1%20%D8%AF%D9%88%D9%84%D8%B3%20%D9%85%D9%86%20%D8%AF%D9%88%D9%84%D8%AA%D8%B4%D9%8A%20%D8%A7%D9%86%D8%AF%20%D8%AC%D8%A7%D8%A8%D8%A7%D9%86%D8%A7%20%D9%84%D9%84%D9%86%D8%B3%D8%A7%D8%A1%20-%20%D8%A3%D9%88%20%D8%AF%D9%8A%20%D8%A8%D8%A7%D8%B1%D9%81%D9%8A%D9%88%D9%85-n6179/?gclid=CjwKCAiA7939BRBMEiwA-hX5J4jhYkAdyiSzflTqnDNAHI8bOo5w2ma9y2zFMcScwK6k065IkZIy0hoCV6gQAvD_BwE">عطر دولس من دولتشي اند جابانا</a>
  </div>
  <a href="https://niceonesa.com/ar/Perfume/%D8%B9%D8%B7%D8%B1%20%D8%AF%D9%88%D9%84%D8%B3%20%D9%85%D9%86%20%D8%AF%D9%88%D9%84%D8%AA%D8%B4%D9%8A%20%D8%A7%D9%86%D8%AF%20%D8%AC%D8%A7%D8%A8%D8%A7%D9%86%D8%A7%20%D9%84%D9%84%D9%86%D8%B3%D8%A7%D8%A1%20-%20%D8%A3%D9%88%20%D8%AF%D9%8A%20%D8%A8%D8%A7%D8%B1%D9%81%D9%8A%D9%88%D9%85-n6179/?gclid=CjwKCAiA7939BRBMEiwA-hX5J4jhYkAdyiSzflTqnDNAHI8bOo5w2ma9y2zFMcScwK6k065IkZIy0hoCV6gQAvD_BwE">
<img src="https://i.ibb.co/MPtRm5m/IMG-2896-x-1629-pixel.jpg" alt="IMG-2896-x-1629-pixel" border="0">
  </a>
  </li>
  <li>
  <div class="image_title">
    <a href="https://bharqan.com/products/a0a20fe3-8427-4bbf-b2bc-50e0c89f2b99">فينا - Vienna</a>
  </div>

  <a href="https://bharqan.com/products/a0a20fe3-8427-4bbf-b2bc-50e0c89f2b99">
  <img src="https://i.ibb.co/tCsCSRs/IMG-2896-x-1629-pixel.jpg" alt="IMG-2896-x-1629-pixel" border="0">
  </a>
  </li>
  </ul>
  </div>






  <footer>
          <div id="left-footer">
              <h3>روابط سريعة</h3>

                  <ul>
                      <li>
                          <a href="Home.php">الرئسية</a>
                      </li>
                      <li>
                          <a href="personality_test.php">اختبار الشخصية</a>
                      </li>
                      <li>
                          <a href="Perfume_concentration.php">تركيز العطر</a>
                      </li>
                      <li>
                          <a href="Types_of_Scent_Families.php">انواع العطور</a>
                      </li>
                      <li>
                          <a href="Share_your_experience.php">شارك تجربتك</a>
                      </li>

                  </ul>

          </div>

          <div id="right-footer">
              <h3>اتبعنا</h3>
              <div id="social-media-footer">
                  <ul>
                      <li>
                          <a href="#">
                              <i class="fab fa-facebook"></i>
                          </a>
                      </li>
                      <li>
                          <a href="#">
                              <i class="fab fa-youtube"></i>
                          </a>
                      </li>
                      <li>
                          <a href="#">
                              <i class="fab fa-github"></i>
                          </a>
                      </li>
                  </ul>
              </div>
              <p>This website is developed by IT Team</p>
          </div>
      </footer>

            <script src="js/j.js"></script>
            <script src="js1/min.js"></script>
            <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
            <!-- Include all compiled plugins (below), or include individual files as needed -->
            <script src="js1/bootstrap.min.js"></script>

    </body>
    </html>
