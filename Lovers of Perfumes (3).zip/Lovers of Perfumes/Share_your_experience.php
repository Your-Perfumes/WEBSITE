<!DOCTYPE html>
<html lang="ar" dir=" ">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">

  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.1.0/css/all.css" integrity="sha384-lKuwvrZot6UHsBSfcMvOkWwlCMgc0TaWr+30HWe3a4ltaBwTZhyTEggF5tJv8tbt"
      crossorigin="anonymous">

  <link rel="stylesheet" href="css1/stylehs.css">
  <link href="css1/c3p.css" rel="stylesheet">
  <title>Lovers of Perfumes</title>
  <style >
    footer {position: relative;top: 350px }
  </style>

</head>
<body>
  <div id="slideout-menu">
        <ul>
            <li>
                <a href="Home.php">الرئسية</a>
            </li>
            <li>
                <a href="Perfume_concentration.php">تركيز العطر</a>
            </li>
            <li>
                <a href="Types_of_Scent_Families.php">انواع العطور</a>
            </li>
            <li>
                <a href="Share_your_experience.php">شارك تجربتك</a>
            </li>

        </ul>
    </div>

    <nav>
        <div id="logo-img">
            <a href="Home.php">
              <img src="https://i.ibb.co/SxZxQHx/1606493021985.png" alt="1606493021985" border="0">

            </a>
        </div>
        <div id="menu-icon">
            <i class="fas fa-bars"></i>
        </div>
        <ul>
            <li>
                <a class="active" href="Home.php">الرئسية</a>
            </li>
            <li>
                <a href="Perfume_concentration.php">تركيز العطر</a>
            </li>
            <li>
                <a href="Types_of_Scent_Families.php">انواع العطور</a>
            </li>
            <li>
                <a href="Share_your_experience.php">شارك تجربتك</a>
            </li>
            <li>
                <div id="search-icon">
                    <i></i>
                </div>
            </li>
        </ul>
    </nav>


<main>
    <section>

      <div class="displayx">

        <h2 >شارك تجربتك </h2>
        <h4 >.كن جزءًا من مجتمع  محبي العطور  , وشارك تجاربك عن العطور ، ابدأ الآن بإضافة تجربتك</h4>

        <a  href="Write_your_experience.php"  class="btn2  btn-primary btn-lg role=" button">شارك تجربتك</a>

        <div class="img-fluid">
        <img src="https://i.ibb.co/511kq0d/ecc6e29be0133c9323aa6c5c7bbaded0.jpg" alt="ecc6e29be0133c9323aa6c5c7bbaded0" border="0" width="300" height"300">
      </div>
      <div class="img-fluid2">
      <img src="https://i.ibb.co/HzzwxfV/5e718be2e16e28348706232df85c8c42.jpg" alt="5e718be2e16e28348706232df85c8c42" border="0" width="300" height"300">
    </div>
    </div>

    </section>


    <footer>
            <div id="left-footer">
                <h3>روابط سريعة</h3>

                    <ul>
                        <li>
                            <a href="Home.php">الرئسية</a>
                        </li>
                        <li>
                            <a href="personality_test.php">اختبار الشخصية</a>
                        </li>
                        <li>
                            <a href="Perfume_concentration.php">تركيز العطر</a>
                        </li>
                        <li>
                            <a href="Types_of_Scent_Families.php">انواع العطور</a>
                        </li>
                        <li>
                            <a href="Share_your_experience.php">شارك تجربتك</a>
                        </li>

                    </ul>

            </div>

            <div id="right-footer">
                <h3>اتبعنا</h3>
                <div id="social-media-footer">
                    <ul>
                        <li>
                            <a href="#">
                                <i class="fab fa-facebook"></i>
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <i class="fab fa-youtube"></i>
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <i class="fab fa-github"></i>
                            </a>
                        </li>
                    </ul>
                </div>
                <p>This website is developed by IT Team</p>
            </div>
        </footer>
        </main>
        <script src="js/j.js"></script>
        <script src="js1/min.js"></script>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
        <!-- Include all compiled plugins (below), or include individual files as needed -->
        <script src="js1/bootstrap.min.js"></script>
</body>
</html>
