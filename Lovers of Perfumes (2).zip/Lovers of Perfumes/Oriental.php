<!DOCTYPE html>
<html lang="ar" dir="">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">

  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.1.0/css/all.css" integrity="sha384-lKuwvrZot6UHsBSfcMvOkWwlCMgc0TaWr+30HWe3a4ltaBwTZhyTEggF5tJv8tbt"
      crossorigin="anonymous">
  <link href="https://fonts.googleapis.com/css?family=Roboto|Roboto+Condensed|Roboto+Slab" rel="stylesheet">
  <link rel="stylesheet" href="css1/stylehs.css">
  <link href="css1/c3p.css" rel="stylesheet">
  <link rel="stylesheet" href="css1/t1.css">
  <title>Lovers of Perfumes</title>



</head>
<body>
  <div id="slideout-menu">
        <ul>
            <li>
                <a href="Home.php">الرئسية</a>
            </li>
            <li>
                <a href="Perfume_concentration.php">تركيز العطر</a>
            </li>
            <li>
                <a href="Types_of_Scent Families.php">انواع العطور</a>
            </li>
            <li>
                <a href="Share_your_experience.php">شارك تجربتك</a>
            </li>

        </ul>
    </div>

    <nav>
        <div id="logo-img">
            <a href="Home.php">
              <img src="https://i.ibb.co/SxZxQHx/1606493021985.png" alt="1606493021985" border="0">

            </a>
        </div>
        <div id="menu-icon">
            <i class="fas fa-bars"></i>
        </div>
        <ul>
            <li>
                <a class="active" href="Home.php">الرئسية</a>
            </li>
            <li>
                <a href="Perfume_concentration.php">تركيز العطر</a>
            </li>
            <li>
                <a href="Types_of_Scent Families.php">انواع العطور</a>
            </li>
            <li>
                <a href="Share_your_experience.php">شارك تجربتك</a>
            </li>
            <li>
                <div id="search-icon">
                    <i></i>
                </div>
            </li>
        </ul>
    </nav>



    <div id="parallax-world-of-ugg">
  <section>
      <div class="parallax-one">
        <h2>العطور الشرقية</h2>
        <h2>(Oriental)</h2>

      </div>
  </section>

  <section>
    <div class="block"><br>
      <p><span class="first-character sc" dir="rtl">|</span><p>وهي العطور الشرقية ، الدافئه ، الفاخرة ، تعتبر من اقدم العطور ولها تاريخ عريق و ممتد لآلاف السنين
من اوائل العطور الشرقية اللي استخدمها الانسان كانت المستكة و التوابل المنقعة في بعض الزيوت
العطور الشرقية كانت ومازالت مرتبطة حتى هذا اليوم ببعض الطقوس الدينية في مدن زي الهند
,او حتى عندنا نحب نبخر يوم الجمعة ، الرجال يحطو دهن عود قبل يروحو المسجد
حتى شفت ناس يعتقدو إن تبخير البيت وقت المغرب بالمستكة يطرد الجن,
تصنف بإنها مغرية ، قوية
 بسبب مكوناتها الدافئة و روائحها الغامضة اللي تعطي انطباع بالجرئة لمقتنيها
هذي الفئه غالباً يتم انتاجها بالشتاء والافضل استخدامها بالمساء والسهرات و المناسبات الخاصة
وهي رمز للطبقة المخملية والترف كون مكوناتها نادرة وغالية وفاخرة
العطور الشرقية غالباً تكون ثقيلة و زيتية عشان كذا هي من اثبت العطور واطولها بقاء وفوحان</p>
  </section>

  <section>
    <div class="parallax-two">
      <h2>الانواع الفرعية</h2>
    </div>
  </section>

  <section>
    <div class="block">
      <span class="first-character ny">|</span>
      <h4>:(Soft oriental)شرقية ناعمة</h4>
    <p>.مزيج من الروائح الزهرية الناعمة و البخور و التوابل الدافئة</p>
    <h4>:( Oriental)شرقية</h4>
    <p>.روائح حلوة ودافئة مثل القرفة و الفانيليا و المسك</p>
    <h4>:(Woody oriental) شرقي خشبي </h4>
    <p>.روائح ترابية مثل الباتشولي و خشب الصندل ممزوجة بمكونات حارة حلوة</p>

    </div>
  </section>

  <section>
    <div class="parallax-three">
      <h2>روائح العطور الشرقية الشائعة</h2>
    </div>
  </section>

  <section>
    <div class="block">
<ul>
<li>الفانيليا</li>
<li>نبات المر (Myrrh)</li>
<li>اليانسون(Anise)</li>
<li>العنبر</li>
<li>المسك</li>
</ul>
    </div>
  </section>

  <section>
    <div class="parallax-four">
    <h2>:أمثلة على العطور</h2>
    </div>
  </section>
  <section>
    <div class="block">
    <h3>:مواقع عربية مشهوره وموثوقه</h3>
    </div>
    <div class="blockimg " >
      <th><a href="https://www.noon.com/saudi-ar/"><img src="https://i.ibb.co/WfVgY5m/Pics-Art-11-20-10-15-33.png" alt="Pics-Art-11-14-01-40-20" ></a></th>

     <th> <a href="https://ar-sa.namshi.com/?utm_source=google&utm_medium=cpc&utm_content=%D9%86%D9%85%D8%B4%D9%8A&utm_campaign=sa_search_cb-010001_namshi_ar_desktop-tab&gclid=CjwKCAiA7939BRBMEiwA-hX5J5ceWIwssbu9sdyX002uxa6hy97XG3DP6MNHuCliIIsmuWjt5iTJ8hoC0H0QAvD_BwE"><img src="https://i.ibb.co/dLvTNJf/Pics-Art-11-20-10-18-17.png" alt="Pics-Art-11-14-01-44-42" ></a></th>

      <th><a href="https://niceonesa.com/ar/"><img src="https://i.ibb.co/6bS7ZF1/Pics-Art-11-20-10-19-26.png" alt="Pics-Art-11-14-01-35-20" ></a></th>

      <th><a href="https://bharqan.com/"><img src="https://i.ibb.co/TgxL7pW/Pics-Art-11-20-10-20-23.png" alt="Pics-Art-11-14-01-51-03"  ></a></th>


    </div>
  </section>

  </div>

  <div class="accordian">
  <ul>
  <li>
  <div class="image_title">
    <a href="https://bharqan.com/products/36b46bc6-e53e-42a9-bd0d-828f1405798a">بدر الحرقان</a>
  </div>
  <a href="https://bharqan.com/products/36b46bc6-e53e-42a9-bd0d-828f1405798a">
  <img src="https://i.ibb.co/6bDrKsd/IMG-2896-x-1629-pixel.jpg" alt="IMG-2896-x-1629-pixel" border="0">
  </a>
  </li>
  <li>
  <div class="image_title">
    <a href="https://store.asqgrp.com/sa_ar/safari-l-homme.html">سفاري هوم</a>
  </div>
  <a href="https://store.asqgrp.com/sa_ar/safari-l-homme.html">
<img src="https://i.ibb.co/f0DZ0n9/IMG-2896-x-1629-pixel.jpg" alt="IMG-2896-x-1629-pixel" border="0">
  </a>
  </li>
  <li>
  <div class="image_title">
    <a href="https://en-sa.namshi.com/buy-joop-femme-joop-eau-de-toilette-100-ml-443116.html">Joop</a>
  </div>
  <div class="img3">
  <a href="https://en-sa.namshi.com/buy-joop-femme-joop-eau-de-toilette-100-ml-443116.html">
<img src="https://i.ibb.co/hKhq7Pb/IMG-2896-x-1629-pixel.jpg" alt="IMG-2896-x-1629-pixel" border="0">
  </a>
  <div>
  </li>
  <li>
  <div class="image_title">
    <a href="https://en-sa.namshi.com/buy-calvin-klein-obsession-for-women-100ml-edp-440290.html?utm_source=google&utm_medium=cpc&utm_content=&utm_campaign=sa_search_pla-smart-shopping-beauty_en&gclid=CjwKCAiA7939BRBMEiwA-hX5J_EutWYhZVc56xsIS1Xtv1GSemUcJrB8mufrIrJncm5IV-ZEoCxD4BoCm08QAvD_BwE">عطر اوبسيشن من كالفن كلاين</a>
  </div>
  <a href="https://en-sa.namshi.com/buy-calvin-klein-obsession-for-women-100ml-edp-440290.html?utm_source=google&utm_medium=cpc&utm_content=&utm_campaign=sa_search_pla-smart-shopping-beauty_en&gclid=CjwKCAiA7939BRBMEiwA-hX5J_EutWYhZVc56xsIS1Xtv1GSemUcJrB8mufrIrJncm5IV-ZEoCxD4BoCm08QAvD_BwE">
<img src="https://i.ibb.co/gDpRqkV/IMG-2896-x-1629-pixel.jpg" alt="IMG-2896-x-1629-pixel" border="0">
  </a>
  </li>
  <li>
  <div class="image_title">
    <a href="https://en-sa.namshi.com/buy-estee-lauder-youth-dew-edp-67ml-w543963a.html?utm_source=google&utm_medium=cpc&utm_content=&utm_campaign=sa_search_pla-smart-shopping-beauty_en&gclid=CjwKCAiA7939BRBMEiwA-hX5JxTB7-R2LPDXSIHUKnmjBIGoKb7qahSvyDRcE7yZYb3hz8LGsaQgrBoCfQsQAvD_BwE">(Youth Dew – Estee Lauder)يوث ديو - إستي لودر</a>
  </div>

  <a href="https://en-sa.namshi.com/buy-estee-lauder-youth-dew-edp-67ml-w543963a.html?utm_source=google&utm_medium=cpc&utm_content=&utm_campaign=sa_search_pla-smart-shopping-beauty_en&gclid=CjwKCAiA7939BRBMEiwA-hX5JxTB7-R2LPDXSIHUKnmjBIGoKb7qahSvyDRcE7yZYb3hz8LGsaQgrBoCfQsQAvD_BwE">
  <img src="https://i.ibb.co/RBNgwV7/IMG-2896-x-1629-pixel.jpg" alt="IMG-2896-x-1629-pixel" border="0">
  </a>
  </li>
  </ul>
  </div>



  <footer>
          <div id="left-footer">
              <h3>روابط سريعة</h3>
              <p>
                  <ul>
                      <li>
                          <a href="Home.php">الرئسية</a>
                      </li>
                      <li>
                          <a href="personality_test.php">اختبار الشخصية</a>
                      </li>
                      <li>
                          <a href="Perfume_concentration.php">تركيز العطر</a>
                      </li>
                      <li>
                          <a href="Types_of_Scent Families.php">انواع العطور</a>
                      </li>
                      <li>
                          <a href="Share_your_experience.php">شارك تجربتك</a>
                      </li>

                  </ul>
              </p>
          </div>

          <div id="right-footer">
              <h3>اتبعنا</h3>
              <div id="social-media-footer">
                  <ul>
                      <li>
                          <a href="#">
                              <i class="fab fa-facebook"></i>
                          </a>
                      </li>
                      <li>
                          <a href="#">
                              <i class="fab fa-youtube"></i>
                          </a>
                      </li>
                      <li>
                          <a href="#">
                              <i class="fab fa-github"></i>
                          </a>
                      </li>
                  </ul>
              </div>
              <p>This website is developed by IT Team</p>
          </div>
      </footer>

            <script src="js/j.js"></script>
            <script src="js1/min.js"></script>
            <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
            <!-- Include all compiled plugins (below), or include individual files as needed -->
            <script src="js1/bootstrap.min.js"></script>

    </body>
    </html>
