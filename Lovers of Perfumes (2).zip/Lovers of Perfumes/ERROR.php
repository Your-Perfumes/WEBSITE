<!DOCTYPE html>
<html lang="ar" dir="rtl">
  <head>
    <meta charset="utf-8">
    <title>error</title>
    <style>
@import url('https://fonts.googleapis.com/css?family=Cairo:400,700&subset=arabic');
.button {
   background-color: #7B68EE;
 border: none;
 color: white;
 padding: 5px 5px;
 text-align: center;
 text-decoration: none;
 display: inline-block;
 font-size: 16px;
 margin: 4px 2px;
 cursor: pointer
}
.button:hover {
  background-color: #9370DB;
}
 BODY{
  text-align: center;
  font-size: 20px;
  font-family: 'Cairo';
  top:100px;
  position:Relative;
}
</style>
  </head>
  <body>
    <img src="https://image.freepik.com/vetores-gratis/minuscu
    los-perfumistas-criando-fragrancias-citricas-e-florais-seg
    urando-uma-fatia-de-flor-e-limao-perto-do-frasco-de-vidro-ilus
    tracao-vetorial-para-loja-de-perfumaria-e-conce
    ito-de-aroma_74855-10174.jpg" alt="عطر" height="350"width="500">

    <p>عذراً!! لم نستطع ايجاد الصفحة.</p>
  <a href="Home.php" class="button"><span>الصفحة الرئيسية</span></a>
  </body>
</html>
