<?php

$link = mysqli_connect("sql302.eb2a.com", "eb2a_27334387", "Bb12345678");

// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}

// Attempt create database query execution
$sql = "CREATE DATABASE eb2a_27334387_perfume";
if(mysqli_query($link, $sql)){
    echo "Database created successfully";
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}

// Close connection
mysqli_close($link);
?>



<?php

$link = mysqli_connect("sql302.eb2a.com", "eb2a_27334387", "Bb12345678","eb2a_27334387_perfume");

// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}

// Attempt create table query execution
$sql = "CREATE TABLE Perfume_Info(
    Id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
    Title VARCHAR(50) NOT NULL,
    Post VARCHAR(100000) NOT NULL
)";
if(mysqli_query($link, $sql)){
    echo "Table created successfully.";
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}

// Close connection
mysqli_close($link);
?>
