<!DOCTYPE html>
<html lang="ar" dir="">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">

  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.1.0/css/all.css" integrity="sha384-lKuwvrZot6UHsBSfcMvOkWwlCMgc0TaWr+30HWe3a4ltaBwTZhyTEggF5tJv8tbt"
      crossorigin="anonymous">
  <link href="https://fonts.googleapis.com/css?family=Roboto|Roboto+Condensed|Roboto+Slab" rel="stylesheet">
  <link rel="stylesheet" href="css1/stylehs.css">
  <link href="css1/c3p.css" rel="stylesheet">
  <title>Lovers of Perfumes</title>


</head>
<body>
  <div id="slideout-menu">
        <ul>
            <li>
                <a href="Home.php">الرئسية</a>
            </li>
            <li>
                <a href="Perfume_concentration.php">تركيز العطر</a>
            </li>
            <li>
                <a href="Types_of_Scent Families.php">انواع العطور</a>
            </li>
            <li>
                <a href="Share_your_experience.php">شارك تجربتك</a>
            </li>

        </ul>
    </div>

    <nav>
        <div id="logo-img">
            <a href="Home.php">
              <img src="https://i.ibb.co/SxZxQHx/1606493021985.png" alt="1606493021985" border="0">

            </a>
        </div>
        <div id="menu-icon">
            <i class="fas fa-bars"></i>
        </div>
        <ul>
            <li>
                <a class="active" href="Home.php">الرئسية</a>
            </li>
            <li>
                <a href="Perfume_concentration.php">تركيز العطر</a>
            </li>
            <li>
                <a href="Types_of_Scent Families.php">انواع العطور</a>
            </li>
            <li>
                <a href="Share_your_experience.php">شارك تجربتك</a>
            </li>
            <li>
                <div id="search-icon">
                    <i></i>
                </div>
            </li>
        </ul>
    </nav>




    <main>
      <section>
            <div class="container">
                <div class="card">
                    <div class="face face1">
                        <div class="content">
                            <h3>Perfume</h3>

                        </div>
                    </div>
                    <div class="face face0">
                        <div class="content">
                          <p>هي أغلى انواع العطور نظرًا حيث يصل تركيز الخلاصة بها إلي 40%, مدة بقاء هذه الأنواع من العطور : 8 إلى 6 ساعات. تباع في أحجام صغيرة نظراً لإرتفاع أسعاره. تعتبر هذه الفئة من العطور مناسبة للأشخاص ذوى البشرة الحساسة نظرًا لقلة نسبة الكحول، ويفضل استخدامها في فصل الشتاء بسبب قوتها.</p>


                        </div>
                    </div>
                </div>
                <div class="card2">
                    <div class="face face2">
                        <div class="content">
                        <h3>Eau de Parfum</h3>
                        </div>
                    </div>
                    <div class="face face0">
                        <div class="content">
                            <p>يتروح تركيز خلاصة العطر(الزيت) فيها بين 15% إلى 20%، ولذلك فهي أقل سعرًا من الفئة السابقة , مدة بقاء هذه الأنواع من العطور : 5 إلى 4 ساعات, كما أنه يعتبر مناسب لأصحاب البشرة الحساسة مقارنة بأنواع العطور الأخرى,.
        تعتبر هذه الفئة من العطور مناسبة للاستخدام أكثر في فصلي الخريف، والشتاء.
        </p>
                        </div>
                    </div>
                </div>
                <div class="card3">
                    <div class="face face3">
                        <div class="content">

                            <h3>Eau de Toilette</h3>
                        </div>
                    </div>
                    <div class="face face0">
                        <div class="content">
                        <p>أما هذا النوع يصل تركيز خلاصة العطور (الزيت) فيها بين 15٪ الى4% من العطر و هو ذو رائحة أخف من او دي برفيوم و أكثر إنتعاشاً، و مناسب أكثر للمناخ الأكثر دفئاً , مدة بقاء هذه الأنواع من العطور : 3 إلى 2 ساعات . ويعتبر من العطور المناسبة للاستخدام اليومي في فصلي الربيع، والصيف.</p>
                        </div>
                    </div>
                </div>
                <div class="card4">
                    <div class="face face4">
                        <div class="content">

                            <h3>Eau de Cologne</h3>
                        </div>
                    </div>
                    <div class="face face0">
                        <div class="content">
                            <p>يحتوي عطر او دي كولونيا على تركيز خلاصة العطور (الزيت) يصل فيها بين 5٪ الى2%، إنه منعش للمناخات الأكثر حرارة و هو من أنواع العطور التي تتبخر سريعاً لذلك فإنها تباع بكميات كبيرة و بسعر أقل من جميع انواع العطور الأخرى و أيضاً تعرف تركيز العطور فيها بأنها الأقل. مدة بقاء هذه الأنواع من العطور :  2 ساعة.</p>

                        </div>
                    </div>
                </div>
                <div class="card5">
                    <div class="face face5">
                        <div class="content">

                            <h3>Eau Fraiche</h3>
                        </div>
                    </div>
                    <div class="face face0">
                        <div class="content">
                            <p>تندرج تحت هذه الفئة العطور الأخف تركيزًا على الإطلاق، حيث تدوم لأقل ساعتين، بسبب أن نسبة تركيز الزيت العطري فيها قليلة جدًا، وتتراوح بين 1% إلى 3% فقط.</p>

                        </div>
                    </div>
                </div>
            </div>
          </section>



          <footer>
                  <div id="left-footer">
                      <h3>روابط سريعة</h3>
                      <p>
                          <ul>
                              <li>
                                  <a href="Home.php">الرئسية</a>
                              </li>
                              <li>
                                  <a href="personality_test.php">اختبار الشخصية</a>
                              </li>
                              <li>
                                  <a href="Perfume_concentration.php">تركيز العطر</a>
                              </li>
                              <li>
                                  <a href="Types_of_Scent Families.php">انواع العطور</a>
                              </li>
                              <li>
                                  <a href="Share_your_experience.php">شارك تجربتك</a>
                              </li>

                          </ul>
                      </p>
                  </div>

                  <div id="right-footer">
                      <h3>اتبعنا</h3>
                      <div id="social-media-footer">
                          <ul>
                              <li>
                                  <a href="#">
                                      <i class="fab fa-facebook"></i>
                                  </a>
                              </li>
                              <li>
                                  <a href="#">
                                      <i class="fab fa-youtube"></i>
                                  </a>
                              </li>
                              <li>
                                  <a href="#">
                                      <i class="fab fa-github"></i>
                                  </a>
                              </li>
                          </ul>
                      </div>
                      <p>This website is developed by IT Team</p>
                  </div>
              </footer>

              <script src="js/j.js"></script>
              <script src="js1/min.js"></script>
              <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
              <!-- Include all compiled plugins (below), or include individual files as needed -->
              <script src="js1/bootstrap.min.js"></script>
      </body>
      </html>
